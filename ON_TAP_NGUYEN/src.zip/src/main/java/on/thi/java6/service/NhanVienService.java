package on.thi.java6.service;

import on.thi.java6.dto.NhanVienCustom;
import on.thi.java6.entity.NhanVien;
import on.thi.java6.repository.NhanVienRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NhanVienService {
    @Autowired
    private NhanVienRepository nhanVienRepository;

    public List<NhanVienCustom> getAll() {
        return nhanVienRepository.getAllNhanVien();
    }

    public Page<NhanVienCustom> getAllNhanVien(Integer page) {
        Pageable pageable = PageRequest.of(page, 5);
        return nhanVienRepository.findAllNhanVienCustom(pageable);
    }

    public NhanVien add(NhanVien nhanVien) {
        return nhanVienRepository.save(nhanVien);
    }
}