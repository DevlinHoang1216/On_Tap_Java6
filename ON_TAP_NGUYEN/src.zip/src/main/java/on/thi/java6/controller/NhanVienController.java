package on.thi.java6.controller;

import on.thi.java6.entity.NhanVien;
import on.thi.java6.repository.ChucVuRepository;
import on.thi.java6.service.NhanVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/nhanVien")
public class NhanVienController {
    @Autowired
    private NhanVienService nhanvienService;




    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(nhanvienService.getAll());
    }

    @GetMapping("/getAll")
    public ResponseEntity<?> getAll(@RequestParam (defaultValue = "0", name = "page")Integer page) {
        return ResponseEntity.ok(nhanvienService.getAllNhanVien(page));
    }
    @PostMapping("/add")
    public ResponseEntity<NhanVien> addNhanVien(@RequestBody NhanVien nhanVien) {
        NhanVien savedNhanVien = nhanvienService.add(nhanVien);
        return ResponseEntity.ok(savedNhanVien);
    }

}
