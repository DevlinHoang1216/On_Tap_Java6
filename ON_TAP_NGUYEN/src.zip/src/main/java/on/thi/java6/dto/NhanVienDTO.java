package on.thi.java6.dto;

import lombok.Getter;
import lombok.Setter;
import on.thi.java6.entity.NhanVien;

import java.time.LocalDate;

@Getter
@Setter
public class NhanVienDTO {
    private String maNhanVien;
    private String hoTen;
    private LocalDate ngaySinh;
    private Boolean gioiTinh;
    private String maChucVu;

}

