package on.thi.java6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnTapNguyenApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnTapNguyenApplication.class, args);
    }

}
